To compile the processes program - 
$ gcc Assgn2-Primes-proc-ES16BTECH11025.c -lrt -lm

To compile the threads program - 
$ gcc Assgn2-Primes-th-ES16BTECH11025.c -pthread -lm