To run -
$ gcc Assgn1Src-ES16BTECH11025.c -lrt
$ ./a.out

After executing the file, enter a number to compute the Collatz Sequence for.